# API Reference — CBPSBL_RESEARCH_COGNITIVE_v1

## Endpoints

### Run Task

```
POST /api/c/ed1939ec-13ac-4ac7-9703-6e97253ec16b/run
```

**Request:**
```json
{
  "task": "Your task description",
  "context": {},
  "options": {
    "timeout": 30000,
    "provider": "groq"
  }
}
```

**Response:**
```json
{
  "success": true,
  "result": "Task output",
  "metadata": {
    "duration_ms": 1234,
    "provider": "groq",
    "tokens_used": 500
  }
}
```

### Learn

```
POST /api/c/ed1939ec-13ac-4ac7-9703-6e97253ec16b/learn
```

**Request:**
```json
{
  "content": "Learning content",
  "source": "user_feedback",
  "confidence": 0.9
}
```

### Status

```
GET /api/c/ed1939ec-13ac-4ac7-9703-6e97253ec16b/status
```

**Response:**
```json
{
  "name": "CBPSBL_RESEARCH_COGNITIVE_v1",
  "class": "Research",
  "version": "1.0.0",
  "status": "active",
  "metrics": {
    "runs_today": 42,
    "success_rate": 0.95,
    "avg_latency_ms": 850
  }
}
```

## Error Codes

| Code | Description |
|------|-------------|
| 400 | Invalid request |
| 401 | Authentication required |
| 429 | Rate limited |
| 500 | Internal error |

## Rate Limits

- 100 requests per minute per cognitive
- 10,000 requests per day per cognitive
