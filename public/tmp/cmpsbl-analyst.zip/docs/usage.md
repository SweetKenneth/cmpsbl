# Usage Guide — CMPSBL_ALALYST_COGNITIVE_v1

## Installation

```bash
npm install
npm start
```

## Environment Setup

Create a `.env` file:

```env
SUBSTRATE_URL=https://your-substrate-url
SUBSTRATE_KEY=your-anon-key
```

## Basic Usage

```typescript
import cognitive from './src/index';

// Run a task
const result = await cognitive.run('Analyze the market trends for Q1 2026');

// Access specific capabilities
// await cognitive.ingest(...);
// await cognitive.compare(...);
```

## Memory Modes

Current mode: **Persistent**

- **Stateless**: No state between calls
- **Episodic**: Session-only memory
- **Persistent**: Database persistence
- **Cognitive Graph**: Knowledge graph storage
- **Dream Retention**: Dreams as memory insights

## Learning Modes

Active modes: task, supervised, continuous, dream, autodidactic

- **Continuous Learning**: 24/7 learning from all interactions
- **Task Learning**: Learn only during active tasks
- **Dream Learning**: Learn during sleep cycles
- **Supervised Learning**: Learn from operator feedback
- **Autodidactic**: Self-directed learning from API calls

## Upgrade Path

To upgrade this cognitive:
1. Export a new version from Forge
2. Merge configuration changes
3. Run migration scripts if needed
4. Deploy to runtime
