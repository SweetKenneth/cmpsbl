# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJ4Y3JG-CQOW`
**Fingerprint:** `09d1c4bea3108524`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** BOSON, NEUTRINO, HARVEST, PHOTON, FERMION, PLASMA, MUON, QUBIT, MESON, SHADOW, IMMUNITY, RELAY, GLUON, CRYOGEN, ECHO, IDENTITY, CONSCIENCE, COMPASS, SIMULATE, EVOLUTION
**Generated:** 2026-04-03T16:46:14.111Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.txt` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`09d1c4bea3108524`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®