# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJE8I5T-NC7Y`
**Fingerprint:** `47badac2117529a8`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** SHADOW, SKEPTIC, HERALD, SIMULATE, CUSTODIAN, HARVEST, ORACLE, TREATY, SIEVE, EMBARGO, DEFENSE, SYLLOGISM, OBSERVER, RAMPART, BRAIN, TETHER, IDENTITY, TRIBUNAL, PHANTOM, FULCRUM
**Generated:** 2026-04-03T21:06:26.210Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`47badac2117529a8`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®