# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJ6GG7U-EBF7`
**Fingerprint:** `2c8b3cbaef71cecd`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** CONSCIENCE, SIMULATE, HERALD, TRIBUNAL, BRAIN, SKEPTIC, SHADOW, LEXICON, LINEAGE, RELAY, EVOLUTION, ECHO, TETHER, SIEVE, CUSTODIAN, LINGUA, SYLLOGISM, CLARITY, COMPASS, IMMUNITY
**Generated:** 2026-04-03T17:28:36.404Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`2c8b3cbaef71cecd`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®