# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJB00F5-626R`
**Fingerprint:** `b82607914337f881`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** AEGIS, CIPHER, RECON, TEMPEST, SHADE, OBSIDIAN, BULWARK, WRAITH, ECHO, BLACKOUT, OBSERVER, PHANTOM, SIMULATE, SANDBOX, NOCTURNE, DEFENSE, HARVEST, CONSCIENCE, RELAY, GOVERNANCE
**Generated:** 2026-04-03T19:35:45.010Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`b82607914337f881`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®