# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJF01GS-I1XH`
**Fingerprint:** `5fe824a3da09e5d2`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** PRIMITIVE, BEACON, ARCHITECT, ATLAS, ECHO, ENCODE, DECODE, WRAITH, ENGINEER, RAPTOR, EVOLUTION, CORTEX, BRAIN, COMPASS, HARVEST, MEMORY, SHADOW, SOVEREIGN, RELAY, DEFENSE
**Generated:** 2026-04-03T21:27:39.490Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.ts` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`5fe824a3da09e5d2`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®