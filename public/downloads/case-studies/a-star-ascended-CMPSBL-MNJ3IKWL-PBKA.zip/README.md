# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJ3IKWL-PBKA`
**Fingerprint:** `481694a088211ebe`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** TENSOR, GUARDIAN, KINETIC, VECTOR, SWARM, BRAIN, IDENTITY, WELDER, CALIBER, CONSCIENCE, ECHO, HARVEST, SHADOW, SIMULATE, CONDUCTOR, SERVO, ENVIRON, SANDBOX, TREATY, DEFENSE
**Generated:** 2026-04-03T16:06:42.605Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.txt` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`481694a088211ebe`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®