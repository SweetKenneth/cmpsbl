# Error Codes

### CMPSBL-E001
**Trigger:** Circuit breaker tripped
**Resolution:** Automatic recovery via FAILSAFE. No action needed.

### CMPSBL-E002
**Trigger:** Defense layer blocked request
**Resolution:** Check request origin against allowlist.

### CMPSBL-E003
**Trigger:** Governance check failed
**Resolution:** Verify operation is within policy bounds.

### CMPSBL-E004
**Trigger:** BEACON health check timeout
**Resolution:** Check system resource availability.