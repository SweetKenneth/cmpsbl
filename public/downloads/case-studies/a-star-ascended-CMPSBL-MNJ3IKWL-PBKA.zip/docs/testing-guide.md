# Testing Guide

Install: `npm install @cmpsbl/test-harness`
Run: `npx cmpsbl-test --config ./restoration-report.json`

## Steps

1. Install the test harness: npm install @cmpsbl/test-harness
2. Place the restoration-report.json in your project root
3. Run: npx cmpsbl-test --config ./restoration-report.json
4. Review output — each primitive's hardening is verified independently
5. Green = hardening active. Red = review the specific primitive section.