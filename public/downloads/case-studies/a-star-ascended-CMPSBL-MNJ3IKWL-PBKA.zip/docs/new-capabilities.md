# New Capabilities

### Chaos Pen Test Engine [Active]
Automated penetration testing via chaos injection, adversarial simulation, blast radius analysis, and red team automation. Validates resilience postures.

```typescript
import { ChaosPenTest } from '@cmpsbl/cyber';
ChaosPenTest.run({ scenario: 'ransomware', blastRadius: true });
```

### Real-Time IOC Correlator [Active]
Ingests threat intelligence feeds and correlates Indicators of Compromise across telemetry streams in real-time. Maps findings to MITRE ATT&CK techniques.

```typescript
import { IOCCorrelator } from '@cmpsbl/cyber';
IOCCorrelator.ingest(feed, { mitre: true });
```

### Silent Regression Scanner [Passive]
Background scanner that detects behavioral regressions by comparing output signatures against historical baselines.

```typescript
import { RegressionScanner } from '@cmpsbl/runtime';
RegressionScanner.baseline('v2.0');
```

### Device Fingerprint Layer [Passive]
Generates unique device fingerprints from browser/OS signals for fraud detection and session binding. Zero user-visible impact.

```typescript
import { DeviceFingerprint } from '@cmpsbl/runtime';
const fp = DeviceFingerprint.generate();
```

### Sandbox Escalation Guard [Hybrid]
Runs untrusted operations in sandboxed contexts (passive isolation) and actively terminates processes that attempt privilege escalation.

```typescript
import { SandboxGuard } from '@cmpsbl/runtime';
SandboxGuard.execute(untrustedFn);
```

### Rate Limit Intelligence [Hybrid]
Learns normal traffic patterns (passive) and dynamically adjusts rate limits per client/endpoint (active). Prevents abuse while preserving legitimate spikes.

```typescript
import { RateLimiter } from '@cmpsbl/runtime';
RateLimiter.adaptive({ learning: true });
```

### Cognitive Load Profiler [Passive]
Measures code complexity per module and identifies areas where developer cognitive load exceeds maintainability thresholds.

```typescript
import { CognitiveProfiler } from '@cmpsbl/runtime';
CognitiveProfiler.assess('./src');
```

### Canary Deployment Gate [Hybrid]
Routes a configurable percentage of traffic to new code paths. Monitors for anomalies and auto-rolls back if thresholds are breached.

```typescript
import { CanaryGate } from '@cmpsbl/runtime';
CanaryGate.deploy({ trafficPercent: 5 });
```

### Behavioral Audit Trail [Passive]
Records every significant state transition with timestamps, actor IDs, and causal chains. FNV-1a hash-sealed for tamper evidence.

```typescript
import { AuditTrail } from '@cmpsbl/runtime';
AuditTrail.record('user.action', { userId, action });
```

### Permission Boundary Map [Passive]
Visualizes all access control boundaries in your application. Identifies over-privileged paths and shadow admin vectors.

```typescript
import { PermissionMap } from '@cmpsbl/runtime';
PermissionMap.visualize();
```