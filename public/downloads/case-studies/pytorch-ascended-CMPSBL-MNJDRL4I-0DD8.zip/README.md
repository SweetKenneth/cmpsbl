# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJDRL4I-0DD8`
**Fingerprint:** `52e655af798050c8`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** FULCRUM, TREATY, ECHO, FORGE, SYLLOGISM, GOVERNANCE, MIMIC, CUSTODIAN, BRAIN, LINGUA, SANDBOX, IDENTITY, CONSCIENCE, EVOLUTION, TETHER, VERITAS, RAMPART, HERALD, EMBARGO, GAUNTLET
**Generated:** 2026-04-03T20:53:06.065Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`52e655af798050c8`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®