# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJ5AB71-71MP`
**Fingerprint:** `f90f697548eab361`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** CIPHER, WRAITH, BASTION, RECON, OBSIDIAN, WATCHTOWER, VANGUARD, IRONCLAD, SPECTER, SHADOW, NOCTURNE, ECHO, TREATY, LINGUA, EVOLUTION, CONSCIENCE, BRAIN, IDENTITY, DEFENSE, RELAY
**Generated:** 2026-04-03T16:55:43.255Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.rb` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`f90f697548eab361`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®