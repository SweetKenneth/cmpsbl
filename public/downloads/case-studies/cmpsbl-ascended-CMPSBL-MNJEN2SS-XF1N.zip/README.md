# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJEN2SS-XF1N`
**Fingerprint:** `18b8cd05bd02ba6d`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** FAILSAFE, BEACON, ATLAS, MONOLITH, ARCHITECT, ENGINEER, CORTEX, PRIMITIVE, HARVEST, SANDBOX, WRAITH, ORACLE, DECODE, TREATY, FORGE, OBSERVER, EVOLUTION, BRAIN, PHANTOM, REFLEX
**Generated:** 2026-04-03T21:17:34.805Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.js` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`18b8cd05bd02ba6d`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®