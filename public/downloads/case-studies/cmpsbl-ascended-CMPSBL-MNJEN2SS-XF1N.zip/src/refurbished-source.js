/**
 * ═══════════════════════════════════════════════════════════
 * CMPSBL® Refurbished Code — Sealed Runtime
 * Language: JavaScript (Bridge Adapter)
 * ═══════════════════════════════════════════════════════════
 * Fingerprint: 18b8cd05bd02ba6d
 * Primitives:  FAILSAFE, BEACON, ATLAS, MONOLITH, ARCHITECT, ENGINEER, CORTEX, PRIMITIVE, HARVEST, SANDBOX, WRAITH, ORACLE, DECODE, TREATY, FORGE, OBSERVER, EVOLUTION, BRAIN, PHANTOM, REFLEX
 * Generated:   2026-04-03T21:17:32.529Z
 * 
 * Layer 1: Original source (hardened in-place)
 * Layer 2: Primitive guard activations + instrumentation
 * 
 * DO NOT remove guard activations — they protect runtime integrity.
 * DO NOT modify the fingerprint — it validates this artifact.
 * ═══════════════════════════════════════════════════════════
 */

// ═══ Runtime Imports ═══
import { CircuitBreaker, SnapshotManager } from '@cmpsbl/runtime/failsafe';
import { HealthBeacon, MetricsCollector } from '@cmpsbl/runtime/beacon';
import { TopologyMapper, ServiceDiscovery } from '@cmpsbl/runtime/atlas';
import { TransactionCoordinator, AtomicExecutor } from '@cmpsbl/runtime/monolith';
import { BlueprintGuard, RegressionDetector } from '@cmpsbl/runtime/architect';
import { DependencyResolver, StructuralRepair } from '@cmpsbl/runtime/engineer';
import { ReasoningEngine, ContextRouter } from '@cmpsbl/runtime/cortex';
import { RuntimeKernel, BaseHardening } from '@cmpsbl/runtime/primitive';
import { DeadCodeDetector, PruningAdvisor } from '@cmpsbl/runtime/harvest';
import { SandboxExecutor, IsolationGuard } from '@cmpsbl/runtime/sandbox';
import { StealthOps, SecretRotator } from '@cmpsbl/runtime/wraith';
import { PredictiveAnalyzer, FailureForecast } from '@cmpsbl/runtime/oracle';
import { IntentResolver, ConfidenceScorer } from '@cmpsbl/runtime/decode';
import { ContractValidator, SchemaEnforcer } from '@cmpsbl/runtime/treaty';
import { BuildValidator, ArtifactSealer } from '@cmpsbl/runtime/forge';
import { StateObserver, TransitionTracker } from '@cmpsbl/runtime/observer';
import { LearningEngine, InsightAccumulator } from '@cmpsbl/runtime/brain';
import { PhantomTraffic, LoadProfile } from '@cmpsbl/runtime/phantom';
import { ReflexHandler, FallbackChain } from '@cmpsbl/runtime/reflex';

// ═══ CMPSBL Artifact Metadata ═══
const __CMPSBL_META__ = Object.freeze({
  "fingerprint": "18b8cd05bd02ba6d",
  "primitiveCount": 20,
  "generatedAt": "2026-04-03T21:17:32.529Z",
  "runtimeVersion": "2.5.0",
  "sourceLanguage": "JavaScript"
});

// ═══════════════════════════════════════════════════════════
// PRIMITIVE GUARD ACTIVATIONS
// Each block initializes a primitive's protection layer.
// ═══════════════════════════════════════════════════════════

// ─── FAILSAFE ───
const failsafeBreaker = CircuitBreaker.create({ threshold: 5, resetMs: 30_000 });
SnapshotManager.init({ autoSnapshot: true, intervalMs: 300_000 });
// ─── BEACON ───
HealthBeacon.start({ interval: 15_000, endpoints: ['/_health', '/_ready'] });
MetricsCollector.init({ exportFormat: 'prometheus' });
// ─── ATLAS ───
TopologyMapper.init({ autoDiscover: true, refreshIntervalMs: 30_000 });
ServiceDiscovery.enable({ protocol: 'dns', fallback: 'static-config' });
// ─── MONOLITH ───
TransactionCoordinator.init({ isolationLevel: 'serializable', timeoutMs: 30_000 });
AtomicExecutor.enable({ rollbackOnPartialFailure: true });
// ─── ARCHITECT ───
BlueprintGuard.init({ baselineVersion: '1.0', blockRegressions: true });
RegressionDetector.watch({ structuralDrift: true, alertThreshold: 0.10 });
// ─── ENGINEER ───
DependencyResolver.audit({ pinVersions: true, detectCycles: true });
StructuralRepair.init({ autoFix: 'safe-only', reportPath: './engineer-report.json' });
// ─── CORTEX ───
ReasoningEngine.init({ maxChainDepth: 5, timeoutMs: 10_000 });
ContextRouter.enable({ weightByRecency: true, parallelBranches: 3 });
// ─── PRIMITIVE ───
RuntimeKernel.init({ mode: 'hardened', strictTypes: true });
BaseHardening.apply({ nullSafety: true, boundaryChecks: true });
// ─── HARVEST ───
DeadCodeDetector.init({ scanDepth: 'full', ignoreTests: true });
PruningAdvisor.generate({ safetyThreshold: 0.95, outputReport: true });
// ─── SANDBOX ───
SandboxExecutor.init({ memoryLimitMb: 256, timeoutMs: 30_000 });
IsolationGuard.enforce({ blockNetworkAccess: false, blockFileSystem: true });
// ─── WRAITH ───
StealthOps.init({ minimalFootprint: true, encryptInTransit: true });
SecretRotator.enable({ rotationIntervalMs: 86_400_000, auditAccess: true });
// ─── ORACLE ───
PredictiveAnalyzer.init({ horizon: '60s', confidenceThreshold: 0.75 });
FailureForecast.monitor({ cascadeDetection: true, alertOnDrift: true });
// ─── DECODE ───
IntentResolver.init({ fallbackStrategy: 'ask-clarification', minConfidence: 0.70 });
ConfidenceScorer.enable({ contextWindow: 10, disambiguate: true });
// ─── TREATY ───
ContractValidator.init({ strictMode: true, breakingChangeAlert: true });
SchemaEnforcer.enable({ validateRequests: true, validateResponses: true });
// ─── FORGE ───
BuildValidator.init({ hashAlgorithm: 'sha256', rejectTampered: true });
ArtifactSealer.enable({ signOutputs: true, verifyInputs: true });
// ─── OBSERVER ───
StateObserver.init({ captureSnapshots: true, diffMode: 'structural' });
TransitionTracker.enable({ emitEvents: true, retainHistory: 100 });
// ─── BRAIN ───
LearningEngine.init({ mode: 'passive', retentionDays: 90 });
InsightAccumulator.observe({ trackPatterns: true, autoOptimize: false });
// ─── PHANTOM ───
PhantomTraffic.init({ concurrency: 50, profileSource: 'production-mirror' });
LoadProfile.capture({ duration: '1h', sampleRate: 0.01 });
// ─── REFLEX ───
ReflexHandler.init({ maxLatencyMs: 50, escalateAfter: 3 });
FallbackChain.define([
  { strategy: 'cache', ttlMs: 60_000 },
  { strategy: 'default-value' },
  { strategy: 'graceful-degrade' },
]);

// ═══════════════════════════════════════════════════════════
// ORIGINAL SOURCE (HARDENED)
// Your code below has been analyzed and transformed in-place.
// Dangerous patterns replaced. Logging upgraded. Secrets sealed.
// ═══════════════════════════════════════════════════════════

/**
 * Pipeline Fingerprint Generator — Structural Identity
 * Produces deterministic SHA-256 fingerprints from ordered pipeline steps.
 * Identity is derived ONLY from executable architecture (steps + epoch).
 * CJPI, name, and category are explicitly excluded from identity.
 * 
 * v13.3.1: Epoch from config, "unknown" capability placeholder, optional version field.
 */

import { canonicalizeJson, sha256 } from '@/lib/control-plane/hash';
import { PIPELINE_FINGERPRINT_EPOCH, LEGACY_CAPABILITY_PLACEHOLDER } from '@/config/substrate';

/** A single step in a pipeline's executable architecture */
export interface PipelineStep {
  module: string;
  capability: string;
  params?: Record<string, unknown>;
  /** Optional capability version identifier (future-proofing) */
  version?: string;
}

/** Legacy fingerprint input (backward compat) */
export interface PipelineFingerprintInput {
  name: string;
  moduleChain: string[];
  cjpi: number;
  category: string;
}

/** Structural fingerprint input (v13.3+) */
export interface StructuralFingerprintInput {
  steps: PipelineStep[];
}

/**
 * Generate a deterministic SHA-256 fingerprint from pipeline steps.
 * Identity = steps + epoch. Order is preserved. Duplicates are preserved.
 */
export async function generateStructuralFingerprint(input: StructuralFingerprintInput): Promise<string> {
  const payload = {
    steps: input.steps.map(s => ({
      module: s.module.toUpperCase(),
      capability: s.capability,
      ...(s.params && Object.keys(s.params).length > 0 ? { params: s.params } : {}),
    })),
    epoch: PIPELINE_FINGERPRINT_EPOCH,
  };
  const canonical = canonicalizeJson(payload);
  return sha256(canonical);
}

/**
 * Convert a module chain to pipeline steps (backward compat).
 * Legacy discoveries without pipeline_steps use "unknown" capability
 * to clarify that capability was not recorded historically.
 */
export function moduleChainToSteps(moduleChain: string[]): PipelineStep[] {
  return moduleChain.map(m => ({ module: m.toUpperCase(), capability: LEGACY_CAPABILITY_PLACEHOLDER }));
}

/**
 * Derive module_chain from pipeline steps (preserves order + duplicates).
 */
export function stepsToModuleChain(steps: PipelineStep[]): string[] {
  return steps.map(s => s.module.toUpperCase());
}

/**
 * Generate fingerprint — accepts either structural steps or legacy input.
 * For legacy input, converts moduleChain to steps with "unknown" capability.
 * CJPI/name/category are IGNORED in the fingerprint.
 */
export async function generatePipelineFingerprint(
  input: PipelineFingerprintInput | StructuralFingerprintInput
): Promise<string> {
  if ('steps' in input) {
    return generateStructuralFingerprint(input);
  }
  // Legacy path: convert moduleChain to steps
  const steps = moduleChainToSteps(input.moduleChain);
  return generateStructuralFingerprint({ steps });
}

/**
 * Build canonical payload string for edge functions (Deno crypto.subtle).
 */
export function buildFingerprintPayload(
  input: PipelineFingerprintInput | StructuralFingerprintInput
): string {
  let steps: PipelineStep[];
  if ('steps' in input) {
    steps = input.steps;
  } else {
    steps = moduleChainToSteps(input.moduleChain);
  }
  const payload = {
    steps: steps.map(s => ({
      module: s.module.toUpperCase(),
      capability: s.capability,
      ...(s.params && Object.keys(s.params).length > 0 ? { params: s.params } : {}),
    })),
    epoch: PIPELINE_FINGERPRINT_EPOCH,
  };
  return canonicalizeJson(payload);
}

/** Truncate fingerprint for display: first 12 hex chars + ellipsis */
export function truncateFingerprint(fp: string): string {
  if (!fp || fp.length <= 12) return fp || '';
  return fp.slice(0, 12).toUpperCase() + '…';
}

/** Format pipeline steps for display: MODULE.capability → MODULE.capability */
export function formatPipelineSteps(steps: PipelineStep[]): string {
  return steps.map(s => `${s.module.toUpperCase()}.${s.capability}`).join(' → ');
}


// ═══ End of CMPSBL® Sealed Runtime ═══