# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJEYCOS-F1UO`
**Fingerprint:** `7bc9ab831fe3ce53`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** ARCHITECT, DECODE, CORTEX, AUTOMATON, ENCODE, MONOLITH, ENGINEER, PRIMITIVE, ATLAS, RAPTOR, SHADOW, BRAIN, LINGUA, COMPASS, RELAY, CONSCIENCE, TREATY, PHANTOM, SIMULATE, FORGE
**Generated:** 2026-04-03T21:26:20.603Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.js` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`7bc9ab831fe3ce53`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®