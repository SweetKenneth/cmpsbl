# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJBTP5Q-V0OK`
**Fingerprint:** `13c42397bead4a65`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** LIDAR, VECTOR, SWARM, WELDER, FABRICATOR, INSPECTOR, KINETIC, FLUX, GRIPPER, GUARDIAN, CONSCIENCE, LINGUA, SHADOW, BRAIN, HARVEST, SIMULATE, ECHO, DEFENSE, EVOLUTION, ORACLE
**Generated:** 2026-04-03T19:58:45.724Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`13c42397bead4a65`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®