# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJEX0UY-4RGQ`
**Fingerprint:** `91ac14dd4706312f`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** ARCHITECT, ENGINEER, OBSIDIAN, FAILSAFE, PRIMITIVE, HARVEST, ENCODE, BEACON, MONOLITH, DECODE, BRAIN, MEMORY, WRAITH, ECHO, COMPASS, SHADOW, EVOLUTION, RELAY, IMMUNITY, TREATY
**Generated:** 2026-04-03T21:25:18.854Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.js` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`91ac14dd4706312f`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®