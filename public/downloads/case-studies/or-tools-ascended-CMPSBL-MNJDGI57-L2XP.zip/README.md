# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJDGI57-L2XP`
**Fingerprint:** `af7743b905e75374`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** QUBIT, PLASMA, BOSON, MESON, ENTANGLE, LATTICE, CONSCIENCE, PHOTON, ECHO, OBSERVER, NEUTRINO, BRAIN, SANDBOX, MUON, GRAVITON, LINGUA, ORACLE, IMMUNITY, SIMULATE, EVOLUTION
**Generated:** 2026-04-03T20:44:30.578Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`af7743b905e75374`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®