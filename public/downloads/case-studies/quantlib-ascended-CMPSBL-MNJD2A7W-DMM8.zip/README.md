# CMPSBL® Refurbished Code Package

**Serial:** `CMPSBL-MNJD2A7W-DMM8`
**Fingerprint:** `9012a33c2dd6b2ce`
**CJPI Score:** 100 (Apex)
**Primitives Applied:** MUON, FERMION, ENTANGLE, PRISM, BOSON, GLUON, GRAVITON, HADRON, LATTICE, QUBIT, TREATY, LINGUA, RELAY, MEMORY, COMPASS, SOVEREIGN, PHANTOM, EVOLUTION, OBSERVER, SANDBOX
**Generated:** 2026-04-03T20:33:25.515Z

## Contents

- `src/original-source.txt` — Your original code
- `src/refurbished-source.py` — Hardened code with primitive guards
- `restoration-report.json` — Full machine-readable report
- `test-harness.config.json` — Config for @cmpsbl/test-harness
- `LICENSE.html` — Usage license
- `docs/` — Pipeline details, capabilities, testing guide, error codes, CJPI cert

## Quick Start

```bash
npm install @cmpsbl/test-harness
npx cmpsbl-test --config ./restoration-report.json
```

## Support

Visit https://cmpsbl.com and use your fingerprint ID (`9012a33c2dd6b2ce`)
to have DECODE pull up this refurbishment for customer support.

© 2026 PromptFluid™ · CMPSBL®